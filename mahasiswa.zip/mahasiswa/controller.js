'use strict';
var response = require('./res');
var connection = require('./conn');
var encrypt = require('./encrypt_password');
exports.index = function(req, res) {
    response.ok("Hello, pesan ini dari sisi server NodeJS Restful API!", res)
};


exports.mahasiswa = function(req, res) {
    connection.query('SELECT * FROM tbl_mahasiswa', function (error, rows, fields){
        var message;
        if(error){
        message = "Error ketika menampilkan semua data mahasiswa!";
        response.gagal(message, res);
        }else{
        message = "Sukses menampilkan semua data mahasiswa";
        response.ok_with_data(message, rows, res);
        }
    })
;};

exports.findMahasiswa = function(req, res) {
 
    var nim = req.params.nim;
    var message;
    
    if (!nim) {
        message = "Kehilangan beberapa parameter yang dibutuhkan!";
        return response.gagal(message, res);
    }
    connection.query('SELECT * FROM tbl_mahasiswa where nim = ?',
    [ nim ],
    function (error, rows, fields){
        if(error){
            message = "Error ketika mencari mahasiswa yang dimaksud!";
            response.gagal(message, res);
        } else{
            if(rows.length > 0){
                message = "mahasiswa ditemukan";
                response.ok_with_data(message, rows[0], res);
            }else{
                message = "mahasiswa tidak ditemukan!";
                response.gagal(message, res);
            }
        }
    });
};


exports.registerMahasiswa = async function(req, res) {
 
    var nim = req.body.nim
    var nama = req.body.nama;
    var email = req.body.email;
    var prodi = req.body.prodi;
    var jurusan = req.body.jurusan;
    var kelas = req.body.kelas;
    var paralel = req.body.paralel;
    var message;
    
    if (!nim || !nama || !email || !prodi || !jurusan || !kelas|| !paralel) {
            message = "Kehilangan beberapa parameter yang dibutuhkan!";
            return response.gagal(message, res);
        }
    
    await connection.query('SELECT * FROM tbl_mahasiswa where email = ?',
    [ email ],
    function(error, rows, fields){
        if(rows.length > 0){
        message = "Email user telah terdaftar, silahkan pilih yang lain!";
        response.gagal(message, res);
        }else{

            connection.query('INSERT INTO tbl_mahasiswa (nim, nama, email, prodi, jurusan, kelas, paralel) values (?,?,?,?,?,?,?)',
            [ nim, nama, email, prodi, jurusan, kelas, paralel ],
            function (error, rows, fields){
                if(error){
                    message = "Error ketika menambahkan mahasiswa baru!";
                    response.gagal(message, res);
                } else{
                    message = "Berhasil menambahkan mahasiswa baru";
                    response.ok(message, res);
                }
            });
        }
    });
};

exports.updateMahasiswa = async function(req, res){
 
    // req.body contains information of text fields, if there were any
    var nim = req.body.nim
    var nama = req.body.nama;
    var email = req.body.email;
    var prodi = req.body.prodi;
    var jurusan = req.body.jurusan;
    var kelas = req.body.kelas;
    var paralel = req.body.paralel;
    var message;

    if (!nim || !nama || !email || !prodi || !jurusan || !kelas|| !paralel) {
        message = "Kehilangan beberapa parameter yang dibutuhkan!";
        return response.gagal(message, res);
    }
    
       await connection.query('SELECT * FROM tbl_mahasiswa where nim = ?',
       [ nim ],
       function(error, rows, fields){
           if(rows.length > 0){
               var sql_query = 'UPDATE tbl_mahasiswa SET nama = ?, email = ?, prodi = ?, jurusan = ?, kelas = ?, paralel = ? WHERE nim = ?';
               var params = [ nama, email, prodi, jurusan, kelas, paralel, nim ]
               connection.query(sql_query, params, function (error, rows, fields){
                   if(error){
                       message = "Error ketika mengubah data mahasiswa!";
                       response.gagal(message, res);
                   } else{
                       message = "Berhasil mengubah data mahasiswa!";
                       response.ok(message, res);
                   }
                   });
               }else{
                   message = "mahasiswa yang mau diubah telah terhapus!";
                
                   response.gagal(message, res);
               }
       });
   };
exports.deleteMahasiswa = async function(req, res) {
 
    var nim = req.params.nim;
    var message;
    
    if (!nim) {
        message = "Kehilangan beberapa parameter yang dibutuhkan!";
    return response.gagal(message, res);
    }
    await connection.query('SELECT * FROM tbl_mahasiswa where nim = ?',
    [ nim ],
    function(error, rows, fields){
        if(rows.length > 0){
            connection.query('DELETE FROM tbl_mahasiswa WHERE nim = ?',
            [ nim ],
            function (error, rows, fields){
                if(error){
                    message = "Error ketika mahasiswa!";
                    response.gagal(message, res);
                } else{
                    message = "Berhasil mengahapus mahasiswa";
                    response.ok(message, res);
                }
            });
        }else{
            message = "Mahasiswa tidak ditemukan!";
            response.gagal(message, res);
        }
    });
};