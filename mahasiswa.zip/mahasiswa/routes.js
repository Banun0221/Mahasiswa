'use strict';
module.exports = function(app) {
 var todoList = require('./controller');
 //routing untuk index
 app.route('/')
 .get(todoList.index);

 //routing untuk mahasiswa
app.route('/mahasiswas')
.get(todoList.mahasiswa);

app.route('/mahasiswas/:nim')
.get(todoList.findMahasiswa);
app.route('/mahasiswas')
.post(todoList.registerMahasiswa);
app.route('/mahasiswas')
.put(todoList.updateMahasiswa);
app.route('/mahasiswas/:nim')
.delete(todoList.deleteMahasiswa)
};

