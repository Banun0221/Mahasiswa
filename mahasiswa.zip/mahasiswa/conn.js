var mysql = require ('mysql');

var con = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "mahasiswa"
});

con.connect(function (err){
    if(err){
        console.log("error: " +err.message);
        process.exit(1)
    }
    console.log('mysql terkoneksi...')
});

module.exports = con;